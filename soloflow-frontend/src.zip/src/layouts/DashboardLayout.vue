<template>
  <v-app>
    <!-- App Bar -->
    <v-app-bar
      color="primary"
      elevation="2"
      app
      height="64"
      fixed
    >
      <v-app-bar-nav-icon @click="drawer = !drawer" />
      
      <v-app-bar-title class="font-weight-bold">
        SoloFlow
      </v-app-bar-title>

      <v-spacer />

      <!-- User Menu -->
      <v-menu offset-y>
        <template v-slot:activator="{ props }">
          <v-btn v-bind="props" variant="text" class="text-none">
            <v-avatar size="32" class="mr-2" color="white">
              <span class="text-primary font-weight-bold">U</span>
            </v-avatar>
            <span class="d-none d-sm-inline">Usuário</span>
            <v-icon end>mdi-chevron-down</v-icon>
          </v-btn>
        </template>

        <v-list min-width="200">
          <v-list-item>
            <v-list-item-title class="text-caption text-medium-emphasis">
              usuario@exemplo.com
            </v-list-item-title>
          </v-list-item>
          
          <v-divider class="my-1" />
          
          <v-list-item @click="profile" link>
            <template v-slot:prepend>
              <v-icon color="primary" size="small">mdi-account</v-icon>
            </template>
            <v-list-item-title>Meu Perfil</v-list-item-title>
          </v-list-item>
          
          <v-list-item @click="settings" link>
            <template v-slot:prepend>
              <v-icon color="primary" size="small">mdi-cog</v-icon>
            </template>
            <v-list-item-title>Configurações</v-list-item-title>
          </v-list-item>
          
          <v-divider class="my-1" />
          
          <v-list-item @click="logout" link class="text-error">
            <template v-slot:prepend>
              <v-icon color="error" size="small">mdi-logout</v-icon>
            </template>
            <v-list-item-title>Sair do Sistema</v-list-item-title>
          </v-list-item>
        </v-list>
      </v-menu>
    </v-app-bar>

    <!-- Navigation Drawer -->
    <v-navigation-drawer 
      v-model="drawer" 
      app 
      :width="240"
      class="drawer-custom"
      style="top: 64px !important; height: calc(100vh - 64px) !important;"
    >
      <v-list nav density="compact" class="pt-4">
        <v-list-item
          v-for="item in menuItems"
          :key="item.title"
          @click="item.click"
          link
          color="primary"
          rounded="xl"
          class="mx-3 my-1"
        >
          <template v-slot:prepend>
            <v-icon size="20">{{ item.icon }}</v-icon>
          </template>
          <v-list-item-title class="text-body-2">{{ item.title }}</v-list-item-title>
        </v-list-item>
      </v-list>
    </v-navigation-drawer>

    <!-- Main Content -->
    <v-main class="main-content" style="padding-top: 64px !important;">
      <div class="content-container">
        <!-- Router View para mostrar as páginas -->
        <router-view v-slot="{ Component }">
          <transition name="fade" mode="out-in">
            <component :is="Component" v-if="Component" />
            <!-- Fallback content apenas se não houver componente -->
            <div v-else class="dashboard-fallback">
              <h1>Dashboard SoloFlow</h1>
              <p>Sistema funcionando corretamente!</p>
              
              <!-- Cards de exemplo -->
              <v-row class="mt-4">
                <v-col cols="12" md="3">
                  <v-card color="orange-lighten-4">
                    <v-card-text>
                      <div class="text-h6">Tarefas Pendentes</div>
                      <div class="text-h4">0</div>
                    </v-card-text>
                  </v-card>
                </v-col>
                
                <v-col cols="12" md="3">
                  <v-card color="blue-lighten-4">
                    <v-card-text>
                      <div class="text-h6">Processos Ativos</div>
                      <div class="text-h4">0</div>
                    </v-card-text>
                  </v-card>
                </v-col>
                
                <v-col cols="12" md="3">
                  <v-card color="green-lighten-4">
                    <v-card-text>
                      <div class="text-h6">Concluídos Hoje</div>
                      <div class="text-h4">0</div>
                    </v-card-text>
                  </v-card>
                </v-col>
                
                <v-col cols="12" md="3">
                  <v-card color="purple-lighten-4">
                    <v-card-text>
                      <div class="text-h6">Total do Mês</div>
                      <div class="text-h4">0</div>
                    </v-card-text>
                  </v-card>
                </v-col>
              </v-row>
            </div>
          </transition>
        </router-view>
      </div>
    </v-main>
  </v-app>
</template>

<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'

const router = useRouter()
const drawer = ref(true)
const rail = ref(false)

// Função para navegar
function navigateTo(path) {
  console.log('Navegando para:', path)
  router.push(path).catch(err => {
    console.error('Erro na navegação:', err)
  })
}

const menuItems = [
  {
    title: 'Dashboard',
    icon: 'mdi-view-dashboard',
    to: '/dashboard',
    click: () => navigateTo('/dashboard')
  },
  {
    title: 'Processos',
    icon: 'mdi-clipboard-list', 
    to: '/processes',
    click: () => navigateTo('/processes')
  },
  {
    title: 'Tipos de Processo',
    icon: 'mdi-file-cog',
    to: '/process-types',
    click: () => navigateTo('/process-types')
  },
  {
    title: 'Setores',
    icon: 'mdi-office-building',
    to: '/sectors',
    click: () => navigateTo('/sectors')
  },
  {
    title: 'Usuários',
    icon: 'mdi-account-group',
    to: '/users',
    click: () => navigateTo('/users')
  },
  {
    title: 'Empresas',
    icon: 'mdi-domain',
    to: '/companies',
    click: () => navigateTo('/companies')
  }
]

function profile() {
  console.log('Acessar perfil')
  // router.push('/profile')
}

function settings() {
  console.log('Acessar configurações')
  // router.push('/settings')
}

function logout() {
  console.log('Executando logout...')
  
  // Opção 1: Redirecionar para login
  router.push('/login').catch(err => console.error(err))
  
  // Opção 2: Limpar localStorage e recarregar página
  // localStorage.clear()
  // window.location.reload()
  
  // Opção 3: Se você tiver authStore
  // const authStore = useAuthStore()
  // authStore.logout()
}
</script>


<style scoped>
.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.3s ease;
}

.fade-enter-from,
.fade-leave-to {
  opacity: 0;
}

.main-content {
  background-color: #f5f5f5;
}

.content-container {
  padding: 24px;
  max-width: 100%;
  overflow-x: hidden;
}

.drawer-custom {
  border-right: 1px solid rgba(0,0,0,0.12);
}

.v-list-item {
  min-height: 40px !important;
}

.v-list-item__prepend {
  width: 24px !important;
  min-width: 24px !important;
}

.v-list-item__prepend > .v-icon {
  margin-inline-end: 16px !important;
}

.dashboard-fallback {
  padding: 0;
}

/* Responsive adjustments */
@media (max-width: 960px) {
  .content-container {
    padding: 16px;
  }
}
</style>