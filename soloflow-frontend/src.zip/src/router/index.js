import { createRouter, createWebHistory } from 'vue-router'
import { useAuthStore } from '@/stores/auth'

// Layouts
import AuthLayout from '@/layouts/AuthLayout.vue'
import DashboardLayout from '@/layouts/DashboardLayout.vue'

// Views - Auth
import Login from '@/views/auth/Login.vue'
import Register from '@/views/auth/Register.vue'

// Views - Dashboard
import Dashboard from '@/views/Dashboard.vue'

// Views - Companies
import Companies from '@/views/companies/Companies.vue'

// Views - Users
import Users from '@/views/users/Users.vue'

// Views - Sectors
import Sectors from '@/views/sectors/Sectors.vue'

// Views - Process Types
import ProcessTypes from '@/views/processes/ProcessTypes.vue'
import ProcessTypeEditor from '@/views/processes/ProcessTypeEditor.vue'

// Views - Processes
import Processes from '@/views/processes/Processes.vue'
import ProcessDetail from '@/views/processes/ProcessDetail.vue'
import StepExecution from '@/views/processes/StepExecution.vue'

const routes = [
  {
    path: '/',
    redirect: '/dashboard',
  },
  {
    path: '/login',
    component: AuthLayout,
    children: [
      {
        path: '',
        name: 'Login',
        component: Login,
        meta: { requiresGuest: true },
      },
    ],
  },
  {
    path: '/register',
    component: AuthLayout,
    children: [
      {
        path: '',
        name: 'Register',
        component: Register,
        meta: { requiresGuest: true },
      },
    ],
  },
  {
    path: '/dashboard',
    component: DashboardLayout,
    meta: { requiresAuth: true },
    children: [
      {
        path: '',
        name: 'Dashboard',
        component: Dashboard,
      },
      // Companies
      {
        path: '/companies',
        name: 'Companies',
        component: Companies,
        meta: { requiresRole: ['ADMIN'] },
      },
      // Users
      {
        path: '/users',
        name: 'Users',
        component: Users,
        meta: { requiresRole: ['ADMIN', 'MANAGER'] },
      },
      // Sectors
      {
        path: '/sectors',
        name: 'Sectors',
        component: Sectors,
        meta: { requiresRole: ['ADMIN', 'MANAGER'] },
      },
      // Process Types
      {
        path: '/process-types',
        name: 'ProcessTypes',
        component: ProcessTypes,
        meta: { requiresRole: ['ADMIN', 'MANAGER'] },
      },
      {
        path: '/process-types/new',
        name: 'ProcessTypeNew',
        component: ProcessTypeEditor,
        meta: { requiresRole: ['ADMIN', 'MANAGER'] },
      },
      {
        path: '/process-types/:id/edit',
        name: 'ProcessTypeEdit',
        component: ProcessTypeEditor,
        meta: { requiresRole: ['ADMIN', 'MANAGER'] },
      },
      


      // Processes
      {
        path: '/processes',
        name: 'Processes',
        component: Processes,
      },
      {
        path: '/processes/:id',
        name: 'ProcessDetail',
        component: ProcessDetail,
      },
      {
        path: '/processes/:id/execute/:stepId',
        name: 'StepExecution',
        component: StepExecution,
      },
    ],
  },
  {
    path: '/:pathMatch(.*)*',
    redirect: '/dashboard',
  },
]

const router = createRouter({
  history: createWebHistory(),
  routes,
})

// Navigation guards
router.beforeEach((to, from, next) => {
  const authStore = useAuthStore()
  
  // Inicializar auth do localStorage
  if (!authStore.user) {
    authStore.initializeAuth()
  }

  const isAuthenticated = authStore.isAuthenticated
  const userRole = authStore.userRole

  // Rota requer autenticação
  if (to.meta.requiresAuth && !isAuthenticated) {
    next('/login')
    return
  }

  // Rota requer que seja visitante (não autenticado)
  if (to.meta.requiresGuest && isAuthenticated) {
    next('/dashboard')
    return
  }

  // Rota requer role específica
  if (to.meta.requiresRole) {
    const allowedRoles = to.meta.requiresRole
    if (!allowedRoles.includes(userRole)) {
      next('/dashboard')
      return
    }
  }

  next()
})

export default router