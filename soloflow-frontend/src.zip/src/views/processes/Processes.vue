<template>
  <div>
    <!-- Header -->
    <div class="d-flex align-center justify-space-between mb-6">
      <div>
        <h1 class="text-h4 font-weight-bold">Processos</h1>
        <p class="text-subtitle-1 text-medium-emphasis">
          Gerencie e acompanhe os processos da empresa
        </p>
      </div>
      <v-btn
        color="primary"
        @click="newProcessDialog = true"
        prepend-icon="mdi-plus"
      >
        Novo Processo
      </v-btn>
    </div>

    <!-- Filtros -->
    <v-card class="mb-6">
      <v-card-text>
        <v-row>
          <v-col cols="12" md="4">
            <v-text-field
              v-model="filters.search"
              label="Buscar processo"
              prepend-inner-icon="mdi-magnify"
              clearable
              hide-details
            />
          </v-col>
          <v-col cols="12" md="4">
            <v-select
              v-model="filters.processTypeId"
              :items="processTypes"
              item-title="name"
              item-value="id"
              label="Tipo de Processo"
              clearable
              hide-details
            />
          </v-col>
          <v-col cols="12" md="4">
            <v-select
              v-model="filters.status"
              :items="statusOptions"
              label="Status"
              clearable
              hide-details
            />
          </v-col>
        </v-row>
      </v-card-text>
    </v-card>

    <!-- Tabela de Processos -->
    <v-card>
      <v-data-table
        :headers="headers"
        :items="filteredProcesses"
        :loading="loading"
        :items-per-page="10"
        class="elevation-0"
      >
        <template v-slot:item.code="{ item }">
          <v-chip
            size="small"
            variant="tonal"
            @click="viewProcess(item)"
            class="cursor-pointer"
          >
            {{ item.code }}
          </v-chip>
        </template>

        <template v-slot:item.currentStep="{ item }">
          <div v-if="getCurrentStep(item)">
            <v-icon size="16" class="mr-1">
              {{ getStepTypeIcon(getCurrentStep(item).step.type) }}
            </v-icon>
            {{ getCurrentStep(item).step.name }}
          </div>
          <span v-else class="text-grey">-</span>
        </template>

        <template v-slot:item.status="{ item }">
          <v-chip
            :color="getStatusColor(item.status)"
            size="small"
            label
          >
            {{ getStatusText(item.status) }}
          </v-chip>
        </template>

        <template v-slot:item.createdAt="{ item }">
          {{ formatDate(item.createdAt) }}
        </template>

        <template v-slot:item.actions="{ item }">
          <v-btn
            icon="mdi-eye"
            size="small"
            variant="text"
            @click="viewProcess(item)"
          />
          <v-btn
            v-if="canExecute(item)"
            icon="mdi-play"
            size="small"
            variant="text"
            color="primary"
            @click="executeProcess(item)"
          />
        </template>
      </v-data-table>
    </v-card>

    <!-- Dialog Novo Processo -->
    <v-dialog
      v-model="newProcessDialog"
      max-width="600"
    >
      <v-card>
        <v-card-title>Novo Processo</v-card-title>
        <v-divider />
        
        <v-form ref="newProcessForm" v-model="newProcessValid">
          <v-card-text>
            <v-select
              v-model="newProcess.processTypeId"
              :items="processTypes"
              item-title="name"
              item-value="id"
              label="Tipo de Processo"
              :rules="[v => !!v || 'Selecione um tipo de processo']"
              required
            >
              <template v-slot:item="{ item, props }">
                <v-list-item v-bind="props">
                  <v-list-item-subtitle>
                    {{ item.description }}
                  </v-list-item-subtitle>
                </v-list-item>
              </template>
            </v-select>

            <v-text-field
              v-model="newProcess.title"
              label="Título"
              class="mt-4"
            />

            <v-textarea
              v-model="newProcess.description"
              label="Descrição"
              rows="3"
              class="mt-4"
            />
          </v-card-text>

          <v-divider />

          <v-card-actions>
            <v-spacer />
            <v-btn
              variant="text"
              @click="newProcessDialog = false"
            >
              Cancelar
            </v-btn>
            <v-btn
              color="primary"
              variant="elevated"
              :loading="creating"
              :disabled="!newProcessValid"
              @click="createProcess"
            >
              Criar
            </v-btn>
          </v-card-actions>
        </v-form>
      </v-card>
    </v-dialog>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { useAuthStore } from '@/stores/auth'
import { useProcessStore } from '@/stores/processes'
import { useProcessTypeStore } from '@/stores/processTypes'
import dayjs from 'dayjs'

const router = useRouter()
const authStore = useAuthStore()
const processStore = useProcessStore()
const processTypeStore = useProcessTypeStore()

// Estado
const newProcessDialog = ref(false)
const newProcessValid = ref(false)
const creating = ref(false)

const filters = ref({
  search: '',
  processTypeId: null,
  status: null
})

const newProcess = ref({
  processTypeId: null,
  title: '',
  description: ''
})

// Computed
const loading = computed(() => processStore.loading)
const processes = computed(() => processStore.processes)
const processTypes = computed(() => processTypeStore.processTypes)

const filteredProcesses = computed(() => {
  let result = processes.value

  if (filters.value.search) {
    const search = filters.value.search.toLowerCase()
    result = result.filter(p => 
      p.code.toLowerCase().includes(search) ||
      p.title?.toLowerCase().includes(search) ||
      p.processType.name.toLowerCase().includes(search)
    )
  }

  if (filters.value.processTypeId) {
    result = result.filter(p => p.processTypeId === filters.value.processTypeId)
  }

  if (filters.value.status) {
    result = result.filter(p => p.status === filters.value.status)
  }

  return result
})

// Headers
const headers = [
  { title: 'Código', key: 'code', width: '120' },
  { title: 'Título', key: 'title' },
  { title: 'Tipo', key: 'processType.name' },
  { title: 'Etapa Atual', key: 'currentStep' },
  { title: 'Solicitante', key: 'createdBy.name' },
  { title: 'Criado em', key: 'createdAt' },
  { title: 'Status', key: 'status', align: 'center' },
  { title: 'Ações', key: 'actions', align: 'center', sortable: false }
]

// Opções
const statusOptions = [
  { title: 'Rascunho', value: 'DRAFT' },
  { title: 'Em Andamento', value: 'IN_PROGRESS' },
  { title: 'Concluído', value: 'COMPLETED' },
  { title: 'Cancelado', value: 'CANCELLED' },
  { title: 'Rejeitado', value: 'REJECTED' }
]

// Métodos auxiliares
function getStepTypeIcon(type) {
  const icons = {
    INPUT: 'mdi-form-textbox',
    APPROVAL: 'mdi-check-decagram',
    UPLOAD: 'mdi-upload',
    REVIEW: 'mdi-eye-check',
    SIGNATURE: 'mdi-draw-pen'
  }
  return icons[type] || 'mdi-help-circle'
}

function getStatusColor(status) {
  const colors = {
    DRAFT: 'grey',
    IN_PROGRESS: 'info',
    COMPLETED: 'success',
    CANCELLED: 'error',
    REJECTED: 'error'
  }
  return colors[status] || 'grey'
}

function getStatusText(status) {
  const texts = {
    DRAFT: 'Rascunho',
    IN_PROGRESS: 'Em Andamento',
    COMPLETED: 'Concluído',
    CANCELLED: 'Cancelado',
    REJECTED: 'Rejeitado'
  }
  return texts[status] || status
}

function getCurrentStep(process) {
  return process.stepExecutions?.find(se => se.status === 'IN_PROGRESS')
}

function canExecute(process) {
  if (process.status !== 'IN_PROGRESS') return false
  
  const currentStep = getCurrentStep(process)
  if (!currentStep) return false

  const user = authStore.user
  const step = currentStep.step

  // Verificar se é responsável direto
  if (step.assignedToUserId === user.id) return true
  
  // Verificar se pertence ao setor responsável
  if (step.assignedToSectorId && user.sectorId === step.assignedToSectorId) return true

  return false
}

function formatDate(date) {
  return dayjs(date).format('DD/MM/YYYY HH:mm')
}

// Métodos
function viewProcess(process) {
  router.push(`/processes/${process.id}`)
}

function executeProcess(process) {
  const currentStep = getCurrentStep(process)
  if (currentStep) {
    router.push(`/processes/${process.id}/execute/${currentStep.id}`)
  }
}

async function createProcess() {
  if (!newProcessValid.value) return

  creating.value = true
  try {
    const data = {
      processTypeId: newProcess.value.processTypeId,
      title: newProcess.value.title,
      description: newProcess.value.description
    }

    const created = await processStore.createProcess(data)
    window.showSnackbar('Processo criado com sucesso!', 'success')
    
    newProcessDialog.value = false
    newProcess.value = {
      processTypeId: null,
      title: '',
      description: ''
    }

    // Ir para o processo criado
    router.push(`/processes/${created.id}`)
  } catch (error) {
    window.showSnackbar(error.message || 'Erro ao criar processo', 'error')
  } finally {
    creating.value = false
  }
}

async function loadData() {
  await Promise.all([
    processStore.fetchProcesses(),
    processTypeStore.fetchProcessTypes()
  ])
}

onMounted(() => {
  loadData()
})
</script>

<style scoped>
.cursor-pointer {
  cursor: pointer;
}
</style>